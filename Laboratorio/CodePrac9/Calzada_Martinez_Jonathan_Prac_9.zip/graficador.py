import turtle   #Se importa la biblioteca Turtle
#CALZADA Martinez Jonathan Omar
def main(): #se define la funcion main y se abre el archivo"dibujo txt"
	t=turtle.Turtle()
	ventana=t.getscreen()     
	ventana.bgcolor("cyan")
	archivo=open("dibujo.txt") 
	turtle.pensize(5)
	turtle.color("red")
	turtle.goto(300, 0)
	turtle.goto(0,0)
	turtle.goto(0,200)
	for renglon in archivo: # Se crea for para leer cada renglon
		texto = renglon.split(", ")
		comando = texto[0].lower()
		if comando == "mover":
			x=float(texto[1])
			y=float(texto[2])
			ancho=float(texto[3].strip())
			color=texto[4].strip()
			t.width(ancho)
			t.pencolor(color)
			t.goto(x,y)

		if comando=="circulo":  #If para leer la instruccion crear circulo 
			r=float(texto[1]) 
			a=float(texto[2])
			color=texto[3].strip()
			t.begin_fill()
			t.pendown()
			t.width(a)
			t.circle(r)
			t.end_fill()
			t.penup()

		if comando=="comenzarrelleno":  #if para leer la instruccion comenzar relleno
			color=texto[1].strip()
			t.color(color)
			t.begin_fill()
		
		if comando=="terminarrelleno": #If para leer la instruccion terminar Relleno
			t.end_fill()
		
		if comando=="subirpluma": #if para leer la instruccion subir pluma
			print("Hola mundo")
			t.penup()
			
			#t.up()

		if comando=="bajarpluma": #if para leer la instruccion bajar pluma
			t.pendown()
			#t.pd()
			#t.down()


	archivo.close()     # se cierra el archivo y termina el programa
	turtle.exitonclick()
if __name__=="__main__":
	main()